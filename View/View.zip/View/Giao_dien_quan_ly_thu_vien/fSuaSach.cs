﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Giao_dien_quan_ly_thu_vien
{
    public partial class fSuaSach : Form
    {
        public fSuaSach()
        {
            InitializeComponent();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void fThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbMaTacGia_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

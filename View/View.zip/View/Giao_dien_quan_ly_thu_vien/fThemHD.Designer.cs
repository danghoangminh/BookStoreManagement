﻿
namespace Giao_dien_quan_ly_thu_vien
{
    partial class fThemHD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.txbMaSach = new System.Windows.Forms.TextBox();
            this.txMaHD = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.txTenNXB = new System.Windows.Forms.Label();
            this.txbTenSach = new System.Windows.Forms.TextBox();
            this.txTenKH = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tTongTien = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dateTimePicker_NamXuatBan = new System.Windows.Forms.DateTimePicker();
            this.txNgayLap = new System.Windows.Forms.Label();
            this.fThoat = new System.Windows.Forms.Button();
            this.bThem = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txbMaSach);
            this.panel2.Controls.Add(this.txMaHD);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(513, 75);
            this.panel2.TabIndex = 2;
            // 
            // txbMaSach
            // 
            this.txbMaSach.Location = new System.Drawing.Point(182, 24);
            this.txbMaSach.Name = "txbMaSach";
            this.txbMaSach.ReadOnly = true;
            this.txbMaSach.Size = new System.Drawing.Size(328, 27);
            this.txbMaSach.TabIndex = 1;
            // 
            // txMaHD
            // 
            this.txMaHD.AutoSize = true;
            this.txMaHD.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txMaHD.Location = new System.Drawing.Point(3, 28);
            this.txMaHD.Name = "txMaHD";
            this.txMaHD.Size = new System.Drawing.Size(137, 23);
            this.txMaHD.TabIndex = 0;
            this.txMaHD.Text = "MÃ HÓA ĐƠN";
            this.txMaHD.Click += new System.EventHandler(this.txMaSach_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel11);
            this.panel1.Controls.Add(this.txbTenSach);
            this.panel1.Controls.Add(this.txTenKH);
            this.panel1.Location = new System.Drawing.Point(12, 93);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(513, 75);
            this.panel1.TabIndex = 4;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.comboBox2);
            this.panel11.Controls.Add(this.txTenNXB);
            this.panel11.Location = new System.Drawing.Point(368, 78);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(539, 75);
            this.panel11.TabIndex = 13;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(208, 23);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(328, 28);
            this.comboBox2.TabIndex = 6;
            // 
            // txTenNXB
            // 
            this.txTenNXB.AutoSize = true;
            this.txTenNXB.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txTenNXB.Location = new System.Drawing.Point(3, 28);
            this.txTenNXB.Name = "txTenNXB";
            this.txTenNXB.Size = new System.Drawing.Size(195, 23);
            this.txTenNXB.TabIndex = 0;
            this.txTenNXB.Text = "TÊN NHÀ XUẤT BẢN";
            // 
            // txbTenSach
            // 
            this.txbTenSach.Location = new System.Drawing.Point(182, 24);
            this.txbTenSach.Name = "txbTenSach";
            this.txbTenSach.Size = new System.Drawing.Size(328, 27);
            this.txbTenSach.TabIndex = 2;
            // 
            // txTenKH
            // 
            this.txTenKH.AutoSize = true;
            this.txTenKH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txTenKH.Location = new System.Drawing.Point(3, 28);
            this.txTenKH.Name = "txTenKH";
            this.txTenKH.Size = new System.Drawing.Size(181, 23);
            this.txTenKH.TabIndex = 0;
            this.txTenKH.Text = "TÊN KHÁCH HÀNG";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Controls.Add(this.tTongTien);
            this.panel3.Location = new System.Drawing.Point(12, 174);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(513, 75);
            this.panel3.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(182, 24);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(328, 27);
            this.textBox1.TabIndex = 1;
            // 
            // tTongTien
            // 
            this.tTongTien.AutoSize = true;
            this.tTongTien.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tTongTien.Location = new System.Drawing.Point(3, 28);
            this.tTongTien.Name = "tTongTien";
            this.tTongTien.Size = new System.Drawing.Size(117, 23);
            this.tTongTien.TabIndex = 0;
            this.tTongTien.Text = "TỔNG TIỀN";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.dateTimePicker_NamXuatBan);
            this.panel8.Controls.Add(this.txNgayLap);
            this.panel8.Location = new System.Drawing.Point(12, 255);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(513, 75);
            this.panel8.TabIndex = 10;
            // 
            // dateTimePicker_NamXuatBan
            // 
            this.dateTimePicker_NamXuatBan.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_NamXuatBan.Location = new System.Drawing.Point(182, 24);
            this.dateTimePicker_NamXuatBan.Name = "dateTimePicker_NamXuatBan";
            this.dateTimePicker_NamXuatBan.Size = new System.Drawing.Size(328, 27);
            this.dateTimePicker_NamXuatBan.TabIndex = 9;
            // 
            // txNgayLap
            // 
            this.txNgayLap.AutoSize = true;
            this.txNgayLap.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txNgayLap.Location = new System.Drawing.Point(3, 28);
            this.txNgayLap.Name = "txNgayLap";
            this.txNgayLap.Size = new System.Drawing.Size(109, 23);
            this.txNgayLap.TabIndex = 0;
            this.txNgayLap.Text = "NGÀY LẬP";
            // 
            // fThoat
            // 
            this.fThoat.Location = new System.Drawing.Point(404, 346);
            this.fThoat.Name = "fThoat";
            this.fThoat.Size = new System.Drawing.Size(121, 29);
            this.fThoat.TabIndex = 16;
            this.fThoat.Text = "THOÁT";
            this.fThoat.UseVisualStyleBackColor = true;
            this.fThoat.Click += new System.EventHandler(this.fThoat_Click);
            // 
            // bThem
            // 
            this.bThem.Location = new System.Drawing.Point(12, 346);
            this.bThem.Name = "bThem";
            this.bThem.Size = new System.Drawing.Size(184, 29);
            this.bThem.TabIndex = 17;
            this.bThem.Text = "THÊM";
            this.bThem.UseVisualStyleBackColor = true;
            // 
            // fThemHD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 384);
            this.Controls.Add(this.bThem);
            this.Controls.Add(this.fThoat);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "fThemHD";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txbMaSach;
        private System.Windows.Forms.Label txMaHD;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label txTenNXB;
        private System.Windows.Forms.TextBox txbTenSach;
        private System.Windows.Forms.Label txTenKH;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label tTongTien;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NamXuatBan;
        private System.Windows.Forms.Label txNgayLap;
        private System.Windows.Forms.Button fThoat;
        private System.Windows.Forms.Button bThem;
    }
}
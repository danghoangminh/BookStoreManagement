﻿
namespace Giao_dien_quan_ly_thu_vien
{
    partial class fThemHoaDon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.txMaKhachHang = new System.Windows.Forms.Label();
            this.cbMaKhachHang = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txbMaSach = new System.Windows.Forms.TextBox();
            this.txTenKhachHang = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txbMaHoaDon = new System.Windows.Forms.TextBox();
            this.txMaHoaDon = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cbMaSach = new System.Windows.Forms.ComboBox();
            this.txMaSach = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txbTenSach = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txMaKhachHang);
            this.panel2.Controls.Add(this.cbMaKhachHang);
            this.panel2.Location = new System.Drawing.Point(12, 93);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(541, 75);
            this.panel2.TabIndex = 2;
            // 
            // txMaKhachHang
            // 
            this.txMaKhachHang.AutoSize = true;
            this.txMaKhachHang.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txMaKhachHang.Location = new System.Drawing.Point(3, 28);
            this.txMaKhachHang.Name = "txMaKhachHang";
            this.txMaKhachHang.Size = new System.Drawing.Size(173, 23);
            this.txMaKhachHang.TabIndex = 0;
            this.txMaKhachHang.Text = "MÃ KHÁCH HÀNG";
            // 
            // cbMaKhachHang
            // 
            this.cbMaKhachHang.FormattingEnabled = true;
            this.cbMaKhachHang.Location = new System.Drawing.Point(210, 23);
            this.cbMaKhachHang.Name = "cbMaKhachHang";
            this.cbMaKhachHang.Size = new System.Drawing.Size(328, 28);
            this.cbMaKhachHang.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txbMaSach);
            this.panel1.Controls.Add(this.txTenKhachHang);
            this.panel1.Location = new System.Drawing.Point(12, 174);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(541, 75);
            this.panel1.TabIndex = 4;
            // 
            // txbMaSach
            // 
            this.txbMaSach.Location = new System.Drawing.Point(210, 24);
            this.txbMaSach.Name = "txbMaSach";
            this.txbMaSach.ReadOnly = true;
            this.txbMaSach.Size = new System.Drawing.Size(328, 27);
            this.txbMaSach.TabIndex = 2;
            // 
            // txTenKhachHang
            // 
            this.txTenKhachHang.AutoSize = true;
            this.txTenKhachHang.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txTenKhachHang.Location = new System.Drawing.Point(3, 28);
            this.txTenKhachHang.Name = "txTenKhachHang";
            this.txTenKhachHang.Size = new System.Drawing.Size(181, 23);
            this.txTenKhachHang.TabIndex = 0;
            this.txTenKhachHang.Text = "TÊN KHÁCH HÀNG";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txbMaHoaDon);
            this.panel3.Controls.Add(this.txMaHoaDon);
            this.panel3.Location = new System.Drawing.Point(12, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(541, 75);
            this.panel3.TabIndex = 4;
            // 
            // txbMaHoaDon
            // 
            this.txbMaHoaDon.Location = new System.Drawing.Point(210, 24);
            this.txbMaHoaDon.Name = "txbMaHoaDon";
            this.txbMaHoaDon.ReadOnly = true;
            this.txbMaHoaDon.Size = new System.Drawing.Size(328, 27);
            this.txbMaHoaDon.TabIndex = 3;
            // 
            // txMaHoaDon
            // 
            this.txMaHoaDon.AutoSize = true;
            this.txMaHoaDon.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txMaHoaDon.Location = new System.Drawing.Point(3, 28);
            this.txMaHoaDon.Name = "txMaHoaDon";
            this.txMaHoaDon.Size = new System.Drawing.Size(137, 23);
            this.txMaHoaDon.TabIndex = 0;
            this.txMaHoaDon.Text = "MÃ HÓA ĐƠN";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.cbMaSach);
            this.panel4.Controls.Add(this.txMaSach);
            this.panel4.Location = new System.Drawing.Point(12, 255);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(541, 75);
            this.panel4.TabIndex = 5;
            // 
            // cbMaSach
            // 
            this.cbMaSach.FormattingEnabled = true;
            this.cbMaSach.Location = new System.Drawing.Point(210, 23);
            this.cbMaSach.Name = "cbMaSach";
            this.cbMaSach.Size = new System.Drawing.Size(328, 28);
            this.cbMaSach.TabIndex = 4;
            // 
            // txMaSach
            // 
            this.txMaSach.AutoSize = true;
            this.txMaSach.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txMaSach.Location = new System.Drawing.Point(3, 28);
            this.txMaSach.Name = "txMaSach";
            this.txMaSach.Size = new System.Drawing.Size(99, 23);
            this.txMaSach.TabIndex = 0;
            this.txMaSach.Text = "MÃ SÁCH";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.txbTenSach);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Location = new System.Drawing.Point(12, 336);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(541, 75);
            this.panel5.TabIndex = 5;
            // 
            // txbTenSach
            // 
            this.txbTenSach.Location = new System.Drawing.Point(210, 24);
            this.txbTenSach.Name = "txbTenSach";
            this.txbTenSach.ReadOnly = true;
            this.txbTenSach.Size = new System.Drawing.Size(328, 27);
            this.txbTenSach.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(3, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "TÊN SÁCH";
            // 
            // fThemHoaDon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(568, 504);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "fThemHoaDon";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label txMaKhachHang;
        private System.Windows.Forms.ComboBox cbMaKhachHang;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label txTenKhachHang;
        private System.Windows.Forms.TextBox txbMaSach;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txbMaHoaDon;
        private System.Windows.Forms.Label txMaHoaDon;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label txMaSach;
        private System.Windows.Forms.ComboBox cbMaSach;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txbTenSach;
        private System.Windows.Forms.Label label1;
    }
}
﻿
namespace Giao_dien_quan_ly_thu_vien
{
    partial class fThemSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.txbMaSach = new System.Windows.Forms.TextBox();
            this.txMaSach = new System.Windows.Forms.Label();
            this.cbMaTacGia = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.txTenNXB = new System.Windows.Forms.Label();
            this.txbTenSach = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txMaTacGia = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txTenLinhVuc = new System.Windows.Forms.Label();
            this.cbMaLinhVuc = new System.Windows.Forms.ComboBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.numericUpDownGiaMua = new System.Windows.Forms.NumericUpDown();
            this.txGiaMua = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.numericUpDownLanTaiBan = new System.Windows.Forms.NumericUpDown();
            this.txLanTaiBan = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.numericUpDownGiaBia = new System.Windows.Forms.NumericUpDown();
            this.txGiaBia = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dateTimePicker_NamXuatBan = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txTenLoaiSach = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.fThoat = new System.Windows.Forms.Button();
            this.bThem = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txbTenTacGia = new System.Windows.Forms.TextBox();
            this.txTenTacGia = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGiaMua)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLanTaiBan)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGiaBia)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel12.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txbMaSach);
            this.panel2.Controls.Add(this.txMaSach);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(513, 75);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // txbMaSach
            // 
            this.txbMaSach.Location = new System.Drawing.Point(182, 24);
            this.txbMaSach.Name = "txbMaSach";
            this.txbMaSach.ReadOnly = true;
            this.txbMaSach.Size = new System.Drawing.Size(328, 27);
            this.txbMaSach.TabIndex = 1;
            // 
            // txMaSach
            // 
            this.txMaSach.AutoSize = true;
            this.txMaSach.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txMaSach.Location = new System.Drawing.Point(3, 28);
            this.txMaSach.Name = "txMaSach";
            this.txMaSach.Size = new System.Drawing.Size(99, 23);
            this.txMaSach.TabIndex = 0;
            this.txMaSach.Text = "MÃ SÁCH";
            // 
            // cbMaTacGia
            // 
            this.cbMaTacGia.FormattingEnabled = true;
            this.cbMaTacGia.Location = new System.Drawing.Point(182, 28);
            this.cbMaTacGia.Name = "cbMaTacGia";
            this.cbMaTacGia.Size = new System.Drawing.Size(328, 28);
            this.cbMaTacGia.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel11);
            this.panel1.Controls.Add(this.txbTenSach);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 93);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(513, 75);
            this.panel1.TabIndex = 3;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.comboBox2);
            this.panel11.Controls.Add(this.txTenNXB);
            this.panel11.Location = new System.Drawing.Point(368, 78);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(539, 75);
            this.panel11.TabIndex = 13;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(208, 23);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(328, 28);
            this.comboBox2.TabIndex = 6;
            // 
            // txTenNXB
            // 
            this.txTenNXB.AutoSize = true;
            this.txTenNXB.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txTenNXB.Location = new System.Drawing.Point(3, 28);
            this.txTenNXB.Name = "txTenNXB";
            this.txTenNXB.Size = new System.Drawing.Size(195, 23);
            this.txTenNXB.TabIndex = 0;
            this.txTenNXB.Text = "TÊN NHÀ XUẤT BẢN";
            // 
            // txbTenSach
            // 
            this.txbTenSach.Location = new System.Drawing.Point(182, 24);
            this.txbTenSach.Name = "txbTenSach";
            this.txbTenSach.Size = new System.Drawing.Size(328, 27);
            this.txbTenSach.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(3, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "TÊN SÁCH";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txMaTacGia);
            this.panel3.Controls.Add(this.cbMaTacGia);
            this.panel3.Location = new System.Drawing.Point(12, 174);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(513, 75);
            this.panel3.TabIndex = 4;
            // 
            // txMaTacGia
            // 
            this.txMaTacGia.AutoSize = true;
            this.txMaTacGia.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txMaTacGia.Location = new System.Drawing.Point(3, 28);
            this.txMaTacGia.Name = "txMaTacGia";
            this.txMaTacGia.Size = new System.Drawing.Size(126, 23);
            this.txMaTacGia.TabIndex = 0;
            this.txMaTacGia.Text = "MÃ TÁC GIẢ";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txTenLinhVuc);
            this.panel4.Controls.Add(this.cbMaLinhVuc);
            this.panel4.Location = new System.Drawing.Point(12, 336);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(513, 75);
            this.panel4.TabIndex = 5;
            // 
            // txTenLinhVuc
            // 
            this.txTenLinhVuc.AutoSize = true;
            this.txTenLinhVuc.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txTenLinhVuc.Location = new System.Drawing.Point(3, 28);
            this.txTenLinhVuc.Name = "txTenLinhVuc";
            this.txTenLinhVuc.Size = new System.Drawing.Size(147, 23);
            this.txTenLinhVuc.TabIndex = 0;
            this.txTenLinhVuc.Text = "TÊN LĨNH VỰC";
            // 
            // cbMaLinhVuc
            // 
            this.cbMaLinhVuc.FormattingEnabled = true;
            this.cbMaLinhVuc.Location = new System.Drawing.Point(182, 23);
            this.cbMaLinhVuc.Name = "cbMaLinhVuc";
            this.cbMaLinhVuc.Size = new System.Drawing.Size(328, 28);
            this.cbMaLinhVuc.TabIndex = 4;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.numericUpDownGiaMua);
            this.panel5.Controls.Add(this.txGiaMua);
            this.panel5.Location = new System.Drawing.Point(13, 579);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(513, 75);
            this.panel5.TabIndex = 6;
            // 
            // numericUpDownGiaMua
            // 
            this.numericUpDownGiaMua.Location = new System.Drawing.Point(182, 24);
            this.numericUpDownGiaMua.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDownGiaMua.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownGiaMua.Name = "numericUpDownGiaMua";
            this.numericUpDownGiaMua.Size = new System.Drawing.Size(328, 27);
            this.numericUpDownGiaMua.TabIndex = 6;
            this.numericUpDownGiaMua.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownGiaMua.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // txGiaMua
            // 
            this.txGiaMua.AutoSize = true;
            this.txGiaMua.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txGiaMua.Location = new System.Drawing.Point(3, 28);
            this.txGiaMua.Name = "txGiaMua";
            this.txGiaMua.Size = new System.Drawing.Size(94, 23);
            this.txGiaMua.TabIndex = 0;
            this.txGiaMua.Text = "GIÁ MUA";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.numericUpDownLanTaiBan);
            this.panel6.Controls.Add(this.txLanTaiBan);
            this.panel6.Location = new System.Drawing.Point(13, 741);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(513, 75);
            this.panel6.TabIndex = 8;
            // 
            // numericUpDownLanTaiBan
            // 
            this.numericUpDownLanTaiBan.Location = new System.Drawing.Point(182, 24);
            this.numericUpDownLanTaiBan.Name = "numericUpDownLanTaiBan";
            this.numericUpDownLanTaiBan.Size = new System.Drawing.Size(328, 27);
            this.numericUpDownLanTaiBan.TabIndex = 8;
            this.numericUpDownLanTaiBan.ValueChanged += new System.EventHandler(this.numericUpDownLanTaiBan_ValueChanged);
            // 
            // txLanTaiBan
            // 
            this.txLanTaiBan.AutoSize = true;
            this.txLanTaiBan.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txLanTaiBan.Location = new System.Drawing.Point(3, 28);
            this.txLanTaiBan.Name = "txLanTaiBan";
            this.txLanTaiBan.Size = new System.Drawing.Size(129, 23);
            this.txLanTaiBan.TabIndex = 0;
            this.txLanTaiBan.Text = "LẦN TÁI BẢN";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.numericUpDownGiaBia);
            this.panel7.Controls.Add(this.txGiaBia);
            this.panel7.Location = new System.Drawing.Point(13, 660);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(513, 75);
            this.panel7.TabIndex = 9;
            // 
            // numericUpDownGiaBia
            // 
            this.numericUpDownGiaBia.Location = new System.Drawing.Point(182, 24);
            this.numericUpDownGiaBia.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDownGiaBia.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownGiaBia.Name = "numericUpDownGiaBia";
            this.numericUpDownGiaBia.Size = new System.Drawing.Size(328, 27);
            this.numericUpDownGiaBia.TabIndex = 7;
            this.numericUpDownGiaBia.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // txGiaBia
            // 
            this.txGiaBia.AutoSize = true;
            this.txGiaBia.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txGiaBia.Location = new System.Drawing.Point(3, 28);
            this.txGiaBia.Name = "txGiaBia";
            this.txGiaBia.Size = new System.Drawing.Size(83, 23);
            this.txGiaBia.TabIndex = 0;
            this.txGiaBia.Text = "GIÁ BÌA";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.dateTimePicker_NamXuatBan);
            this.panel8.Controls.Add(this.label2);
            this.panel8.Location = new System.Drawing.Point(12, 822);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(513, 75);
            this.panel8.TabIndex = 9;
            // 
            // dateTimePicker_NamXuatBan
            // 
            this.dateTimePicker_NamXuatBan.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_NamXuatBan.Location = new System.Drawing.Point(182, 24);
            this.dateTimePicker_NamXuatBan.Name = "dateTimePicker_NamXuatBan";
            this.dateTimePicker_NamXuatBan.Size = new System.Drawing.Size(328, 27);
            this.dateTimePicker_NamXuatBan.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(3, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 23);
            this.label2.TabIndex = 0;
            this.label2.Text = "NĂM XUẤT BẢN";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.txTenLoaiSach);
            this.panel9.Controls.Add(this.comboBox1);
            this.panel9.Location = new System.Drawing.Point(12, 417);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(513, 75);
            this.panel9.TabIndex = 5;
            // 
            // txTenLoaiSach
            // 
            this.txTenLoaiSach.AutoSize = true;
            this.txTenLoaiSach.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txTenLoaiSach.Location = new System.Drawing.Point(3, 28);
            this.txTenLoaiSach.Name = "txTenLoaiSach";
            this.txTenLoaiSach.Size = new System.Drawing.Size(159, 23);
            this.txTenLoaiSach.TabIndex = 0;
            this.txTenLoaiSach.Text = "TÊN LOẠI SÁCH";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(182, 23);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(328, 28);
            this.comboBox1.TabIndex = 5;
            // 
            // fThoat
            // 
            this.fThoat.Location = new System.Drawing.Point(405, 909);
            this.fThoat.Name = "fThoat";
            this.fThoat.Size = new System.Drawing.Size(121, 29);
            this.fThoat.TabIndex = 11;
            this.fThoat.Text = "THOÁT";
            this.fThoat.UseVisualStyleBackColor = true;
            this.fThoat.Click += new System.EventHandler(this.fThoat_Click);
            // 
            // bThem
            // 
            this.bThem.Location = new System.Drawing.Point(12, 909);
            this.bThem.Name = "bThem";
            this.bThem.Size = new System.Drawing.Size(185, 29);
            this.bThem.TabIndex = 12;
            this.bThem.Text = "THÊM";
            this.bThem.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.txbTenTacGia);
            this.panel10.Controls.Add(this.txTenTacGia);
            this.panel10.Location = new System.Drawing.Point(12, 255);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(513, 75);
            this.panel10.TabIndex = 5;
            // 
            // txbTenTacGia
            // 
            this.txbTenTacGia.Location = new System.Drawing.Point(182, 24);
            this.txbTenTacGia.Name = "txbTenTacGia";
            this.txbTenTacGia.ReadOnly = true;
            this.txbTenTacGia.Size = new System.Drawing.Size(328, 27);
            this.txbTenTacGia.TabIndex = 2;
            // 
            // txTenTacGia
            // 
            this.txTenTacGia.AutoSize = true;
            this.txTenTacGia.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txTenTacGia.Location = new System.Drawing.Point(3, 28);
            this.txTenTacGia.Name = "txTenTacGia";
            this.txTenTacGia.Size = new System.Drawing.Size(134, 23);
            this.txTenTacGia.TabIndex = 0;
            this.txTenTacGia.Text = "TÊN TÁC GIẢ";
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.comboBox3);
            this.panel12.Controls.Add(this.label3);
            this.panel12.Location = new System.Drawing.Point(12, 498);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(514, 75);
            this.panel12.TabIndex = 13;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(182, 23);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(328, 28);
            this.comboBox3.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(3, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 23);
            this.label3.TabIndex = 0;
            this.label3.Text = "TÊN NXB";
            // 
            // fThemSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 950);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.bThem);
            this.Controls.Add(this.fThoat);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "fThemSach";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGiaMua)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLanTaiBan)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGiaBia)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txbMaSach;
        private System.Windows.Forms.Label txMaSach;
        private System.Windows.Forms.ComboBox cbMaTacGia;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txbTenSach;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label txMaTacGia;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label txTenLinhVuc;
        private System.Windows.Forms.ComboBox cbMaLinhVuc;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.NumericUpDown numericUpDownGiaMua;
        private System.Windows.Forms.Label txGiaMua;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label txLanTaiBan;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.NumericUpDown numericUpDownGiaBia;
        private System.Windows.Forms.Label txGiaBia;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NamXuatBan;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label txTenLoaiSach;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.NumericUpDown numericUpDownLanTaiBan;
        private System.Windows.Forms.Button fThoat;
        private System.Windows.Forms.Button bThem;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txbTenTacGia;
        private System.Windows.Forms.Label txTenTacGia;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label txTenNXB;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label3;
    }
}
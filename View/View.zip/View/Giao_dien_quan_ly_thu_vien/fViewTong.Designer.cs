﻿
namespace Giao_dien_quan_ly_thu_vien
{
    partial class fViewTong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tÀIKHOẢNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cẬPNHẬTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đĂNGXUẤTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sÁCHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tHÊMSÁCHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xÓASÁCHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sỬASÁCHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lĨNHVỰCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOẠIGIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tÁCGIẢToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hÓAĐƠNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kHOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nHÀXUẤTBẢNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tHỐNGKÊToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tÀIKHOẢNToolStripMenuItem,
            this.sÁCHToolStripMenuItem,
            this.lĨNHVỰCToolStripMenuItem,
            this.lOẠIGIToolStripMenuItem,
            this.tÁCGIẢToolStripMenuItem,
            this.hÓAĐƠNToolStripMenuItem,
            this.kHOToolStripMenuItem,
            this.nHÀXUẤTBẢNToolStripMenuItem,
            this.tHỐNGKÊToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1150, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tÀIKHOẢNToolStripMenuItem
            // 
            this.tÀIKHOẢNToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cẬPNHẬTToolStripMenuItem,
            this.đĂNGXUẤTToolStripMenuItem});
            this.tÀIKHOẢNToolStripMenuItem.Name = "tÀIKHOẢNToolStripMenuItem";
            this.tÀIKHOẢNToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.tÀIKHOẢNToolStripMenuItem.Text = "TÀI KHOẢN";
            // 
            // cẬPNHẬTToolStripMenuItem
            // 
            this.cẬPNHẬTToolStripMenuItem.Name = "cẬPNHẬTToolStripMenuItem";
            this.cẬPNHẬTToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.cẬPNHẬTToolStripMenuItem.Text = "CẬP NHẬT";
            this.cẬPNHẬTToolStripMenuItem.Click += new System.EventHandler(this.cẬPNHẬTToolStripMenuItem_Click);
            // 
            // đĂNGXUẤTToolStripMenuItem
            // 
            this.đĂNGXUẤTToolStripMenuItem.Name = "đĂNGXUẤTToolStripMenuItem";
            this.đĂNGXUẤTToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.đĂNGXUẤTToolStripMenuItem.Text = "ĐĂNG XUẤT";
            this.đĂNGXUẤTToolStripMenuItem.Click += new System.EventHandler(this.đĂNGXUẤTToolStripMenuItem_Click_1);
            // 
            // sÁCHToolStripMenuItem
            // 
            this.sÁCHToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tHÊMSÁCHToolStripMenuItem,
            this.xÓASÁCHToolStripMenuItem,
            this.sỬASÁCHToolStripMenuItem});
            this.sÁCHToolStripMenuItem.Name = "sÁCHToolStripMenuItem";
            this.sÁCHToolStripMenuItem.Size = new System.Drawing.Size(61, 24);
            this.sÁCHToolStripMenuItem.Text = "SÁCH";
            // 
            // tHÊMSÁCHToolStripMenuItem
            // 
            this.tHÊMSÁCHToolStripMenuItem.Name = "tHÊMSÁCHToolStripMenuItem";
            this.tHÊMSÁCHToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.tHÊMSÁCHToolStripMenuItem.Text = "THÊM SÁCH";
            this.tHÊMSÁCHToolStripMenuItem.Click += new System.EventHandler(this.tHÊMSÁCHToolStripMenuItem_Click);
            // 
            // xÓASÁCHToolStripMenuItem
            // 
            this.xÓASÁCHToolStripMenuItem.Name = "xÓASÁCHToolStripMenuItem";
            this.xÓASÁCHToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.xÓASÁCHToolStripMenuItem.Text = "XÓA SÁCH";
            this.xÓASÁCHToolStripMenuItem.Click += new System.EventHandler(this.xÓASÁCHToolStripMenuItem_Click);
            // 
            // sỬASÁCHToolStripMenuItem
            // 
            this.sỬASÁCHToolStripMenuItem.Name = "sỬASÁCHToolStripMenuItem";
            this.sỬASÁCHToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.sỬASÁCHToolStripMenuItem.Text = "SỬA SÁCH";
            this.sỬASÁCHToolStripMenuItem.Click += new System.EventHandler(this.sỬASÁCHToolStripMenuItem_Click);
            // 
            // lĨNHVỰCToolStripMenuItem
            // 
            this.lĨNHVỰCToolStripMenuItem.Name = "lĨNHVỰCToolStripMenuItem";
            this.lĨNHVỰCToolStripMenuItem.Size = new System.Drawing.Size(89, 24);
            this.lĨNHVỰCToolStripMenuItem.Text = "LĨNH VỰC";
            this.lĨNHVỰCToolStripMenuItem.Click += new System.EventHandler(this.lĨNHVỰCToolStripMenuItem_Click);
            // 
            // lOẠIGIToolStripMenuItem
            // 
            this.lOẠIGIToolStripMenuItem.Name = "lOẠIGIToolStripMenuItem";
            this.lOẠIGIToolStripMenuItem.Size = new System.Drawing.Size(96, 24);
            this.lOẠIGIToolStripMenuItem.Text = "LOẠI SÁCH";
            this.lOẠIGIToolStripMenuItem.Click += new System.EventHandler(this.lOẠIGIToolStripMenuItem_Click);
            // 
            // tÁCGIẢToolStripMenuItem
            // 
            this.tÁCGIẢToolStripMenuItem.Name = "tÁCGIẢToolStripMenuItem";
            this.tÁCGIẢToolStripMenuItem.Size = new System.Drawing.Size(77, 24);
            this.tÁCGIẢToolStripMenuItem.Text = "TÁC GIẢ";
            this.tÁCGIẢToolStripMenuItem.Click += new System.EventHandler(this.tÁCGIẢToolStripMenuItem_Click);
            // 
            // hÓAĐƠNToolStripMenuItem
            // 
            this.hÓAĐƠNToolStripMenuItem.Name = "hÓAĐƠNToolStripMenuItem";
            this.hÓAĐƠNToolStripMenuItem.Size = new System.Drawing.Size(92, 24);
            this.hÓAĐƠNToolStripMenuItem.Text = "HÓA ĐƠN";
            this.hÓAĐƠNToolStripMenuItem.Click += new System.EventHandler(this.hÓAĐƠNToolStripMenuItem_Click);
            // 
            // kHOToolStripMenuItem
            // 
            this.kHOToolStripMenuItem.Name = "kHOToolStripMenuItem";
            this.kHOToolStripMenuItem.Size = new System.Drawing.Size(54, 24);
            this.kHOToolStripMenuItem.Text = "KHO";
            this.kHOToolStripMenuItem.Click += new System.EventHandler(this.kHOToolStripMenuItem_Click);
            // 
            // nHÀXUẤTBẢNToolStripMenuItem
            // 
            this.nHÀXUẤTBẢNToolStripMenuItem.Name = "nHÀXUẤTBẢNToolStripMenuItem";
            this.nHÀXUẤTBẢNToolStripMenuItem.Size = new System.Drawing.Size(130, 24);
            this.nHÀXUẤTBẢNToolStripMenuItem.Text = "NHÀ XUẤT BẢN";
            this.nHÀXUẤTBẢNToolStripMenuItem.Click += new System.EventHandler(this.nHÀXUẤTBẢNToolStripMenuItem_Click);
            // 
            // tHỐNGKÊToolStripMenuItem
            // 
            this.tHỐNGKÊToolStripMenuItem.Name = "tHỐNGKÊToolStripMenuItem";
            this.tHỐNGKÊToolStripMenuItem.Size = new System.Drawing.Size(95, 24);
            this.tHỐNGKÊToolStripMenuItem.Text = "THỐNG KÊ";
            this.tHỐNGKÊToolStripMenuItem.Click += new System.EventHandler(this.tHỐNGKÊToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(12, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1126, 477);
            this.panel1.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(1126, 477);
            this.dataGridView1.TabIndex = 0;
            // 
            // fViewTong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1150, 520);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fViewTong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tÀIKHOẢNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sÁCHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lĨNHVỰCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lOẠIGIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tÁCGIẢToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hÓAĐƠNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cẬPNHẬTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đĂNGXUẤTToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripMenuItem tHÊMSÁCHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xÓASÁCHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sỬASÁCHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kHOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nHÀXUẤTBẢNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tHỐNGKÊToolStripMenuItem;
    }
}
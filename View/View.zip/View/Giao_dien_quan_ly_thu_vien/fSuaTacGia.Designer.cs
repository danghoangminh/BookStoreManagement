﻿
namespace Giao_dien_quan_ly_thu_vien
{
    partial class fSuaTacGia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.txMaTacGia = new System.Windows.Forms.Label();
            this.cbMaTacGia = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txbTenTacGia = new System.Windows.Forms.TextBox();
            this.txTenTacGia = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txbQueQuan = new System.Windows.Forms.TextBox();
            this.txQueQuan = new System.Windows.Forms.Label();
            this.bbLuu = new System.Windows.Forms.Button();
            this.fThoat = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.checkBox_NgaySinh = new System.Windows.Forms.CheckBox();
            this.dateTimePicker_NgaySinh = new System.Windows.Forms.DateTimePicker();
            this.txbNgaySinh = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.checkbox_NgayMat = new System.Windows.Forms.CheckBox();
            this.dateTimePicker_NgayMat = new System.Windows.Forms.DateTimePicker();
            this.txNgayMat = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txMaTacGia);
            this.panel2.Controls.Add(this.cbMaTacGia);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(513, 75);
            this.panel2.TabIndex = 3;
            // 
            // txMaTacGia
            // 
            this.txMaTacGia.AutoSize = true;
            this.txMaTacGia.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txMaTacGia.Location = new System.Drawing.Point(3, 28);
            this.txMaTacGia.Name = "txMaTacGia";
            this.txMaTacGia.Size = new System.Drawing.Size(126, 23);
            this.txMaTacGia.TabIndex = 0;
            this.txMaTacGia.Text = "MÃ TÁC GIẢ";
            // 
            // cbMaTacGia
            // 
            this.cbMaTacGia.FormattingEnabled = true;
            this.cbMaTacGia.Location = new System.Drawing.Point(182, 23);
            this.cbMaTacGia.Name = "cbMaTacGia";
            this.cbMaTacGia.Size = new System.Drawing.Size(328, 28);
            this.cbMaTacGia.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txbTenTacGia);
            this.panel1.Controls.Add(this.txTenTacGia);
            this.panel1.Location = new System.Drawing.Point(12, 93);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(513, 75);
            this.panel1.TabIndex = 5;
            // 
            // txbTenTacGia
            // 
            this.txbTenTacGia.Location = new System.Drawing.Point(182, 24);
            this.txbTenTacGia.Name = "txbTenTacGia";
            this.txbTenTacGia.Size = new System.Drawing.Size(328, 27);
            this.txbTenTacGia.TabIndex = 1;
            // 
            // txTenTacGia
            // 
            this.txTenTacGia.AutoSize = true;
            this.txTenTacGia.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txTenTacGia.Location = new System.Drawing.Point(3, 28);
            this.txTenTacGia.Name = "txTenTacGia";
            this.txTenTacGia.Size = new System.Drawing.Size(134, 23);
            this.txTenTacGia.TabIndex = 0;
            this.txTenTacGia.Text = "TÊN TÁC GIẢ";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txbQueQuan);
            this.panel3.Controls.Add(this.txQueQuan);
            this.panel3.Location = new System.Drawing.Point(12, 174);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(513, 75);
            this.panel3.TabIndex = 6;
            // 
            // txbQueQuan
            // 
            this.txbQueQuan.Location = new System.Drawing.Point(182, 24);
            this.txbQueQuan.Name = "txbQueQuan";
            this.txbQueQuan.Size = new System.Drawing.Size(328, 27);
            this.txbQueQuan.TabIndex = 1;
            // 
            // txQueQuan
            // 
            this.txQueQuan.AutoSize = true;
            this.txQueQuan.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txQueQuan.Location = new System.Drawing.Point(3, 28);
            this.txQueQuan.Name = "txQueQuan";
            this.txQueQuan.Size = new System.Drawing.Size(113, 23);
            this.txQueQuan.TabIndex = 0;
            this.txQueQuan.Text = "QUÊ QUÁN";
            // 
            // bbLuu
            // 
            this.bbLuu.Location = new System.Drawing.Point(12, 461);
            this.bbLuu.Name = "bbLuu";
            this.bbLuu.Size = new System.Drawing.Size(182, 29);
            this.bbLuu.TabIndex = 15;
            this.bbLuu.Text = "LƯU";
            this.bbLuu.UseVisualStyleBackColor = true;
            this.bbLuu.Click += new System.EventHandler(this.bbLuu_Click);
            // 
            // fThoat
            // 
            this.fThoat.Location = new System.Drawing.Point(404, 461);
            this.fThoat.Name = "fThoat";
            this.fThoat.Size = new System.Drawing.Size(121, 29);
            this.fThoat.TabIndex = 14;
            this.fThoat.Text = "THOÁT";
            this.fThoat.UseVisualStyleBackColor = true;
            this.fThoat.Click += new System.EventHandler(this.fThoat_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.checkBox_NgaySinh);
            this.panel8.Controls.Add(this.dateTimePicker_NgaySinh);
            this.panel8.Controls.Add(this.txbNgaySinh);
            this.panel8.Location = new System.Drawing.Point(12, 255);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(513, 87);
            this.panel8.TabIndex = 16;
            // 
            // checkBox_NgaySinh
            // 
            this.checkBox_NgaySinh.AutoSize = true;
            this.checkBox_NgaySinh.Location = new System.Drawing.Point(182, 59);
            this.checkBox_NgaySinh.Name = "checkBox_NgaySinh";
            this.checkBox_NgaySinh.Size = new System.Drawing.Size(96, 24);
            this.checkBox_NgaySinh.TabIndex = 10;
            this.checkBox_NgaySinh.Text = "CHƯA RÕ";
            this.checkBox_NgaySinh.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker_NgaySinh
            // 
            this.dateTimePicker_NgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_NgaySinh.Location = new System.Drawing.Point(182, 26);
            this.dateTimePicker_NgaySinh.Name = "dateTimePicker_NgaySinh";
            this.dateTimePicker_NgaySinh.Size = new System.Drawing.Size(328, 27);
            this.dateTimePicker_NgaySinh.TabIndex = 9;
            // 
            // txbNgaySinh
            // 
            this.txbNgaySinh.AutoSize = true;
            this.txbNgaySinh.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txbNgaySinh.Location = new System.Drawing.Point(3, 28);
            this.txbNgaySinh.Name = "txbNgaySinh";
            this.txbNgaySinh.Size = new System.Drawing.Size(117, 23);
            this.txbNgaySinh.TabIndex = 0;
            this.txbNgaySinh.Text = "NGÀY SINH";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.checkbox_NgayMat);
            this.panel4.Controls.Add(this.dateTimePicker_NgayMat);
            this.panel4.Controls.Add(this.txNgayMat);
            this.panel4.Location = new System.Drawing.Point(12, 348);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(513, 89);
            this.panel4.TabIndex = 12;
            // 
            // checkbox_NgayMat
            // 
            this.checkbox_NgayMat.AutoSize = true;
            this.checkbox_NgayMat.Location = new System.Drawing.Point(182, 59);
            this.checkbox_NgayMat.Name = "checkbox_NgayMat";
            this.checkbox_NgayMat.Size = new System.Drawing.Size(96, 24);
            this.checkbox_NgayMat.TabIndex = 11;
            this.checkbox_NgayMat.Text = "CHƯA RÕ";
            this.checkbox_NgayMat.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker_NgayMat
            // 
            this.dateTimePicker_NgayMat.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_NgayMat.Location = new System.Drawing.Point(182, 26);
            this.dateTimePicker_NgayMat.Name = "dateTimePicker_NgayMat";
            this.dateTimePicker_NgayMat.Size = new System.Drawing.Size(328, 27);
            this.dateTimePicker_NgayMat.TabIndex = 9;
            // 
            // txNgayMat
            // 
            this.txNgayMat.AutoSize = true;
            this.txNgayMat.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txNgayMat.Location = new System.Drawing.Point(3, 28);
            this.txNgayMat.Name = "txNgayMat";
            this.txNgayMat.Size = new System.Drawing.Size(114, 23);
            this.txNgayMat.TabIndex = 0;
            this.txNgayMat.Text = "NGÀY MẤT";
            // 
            // fSuaTacGia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(539, 502);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.fThoat);
            this.Controls.Add(this.bbLuu);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "fSuaTacGia";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label txMaTacGia;
        private System.Windows.Forms.ComboBox cbMaTacGia;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txbTenTacGia;
        private System.Windows.Forms.Label txTenTacGia;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txbQueQuan;
        private System.Windows.Forms.Label txQueQuan;
        private System.Windows.Forms.Button bbLuu;
        private System.Windows.Forms.Button fThoat;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.CheckBox checkBox_NgaySinh;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NgaySinh;
        private System.Windows.Forms.Label txbNgaySinh;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.CheckBox checkbox_NgayMat;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NgayMat;
        private System.Windows.Forms.Label txNgayMat;
    }
}